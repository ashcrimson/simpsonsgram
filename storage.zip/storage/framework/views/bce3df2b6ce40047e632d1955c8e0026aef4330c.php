<?php $__env->startComponent('mail::message'); ?>
# YAHOOOO!

Bienvenido a la mejor red social de Springfield.

<?php $__env->startComponent('mail::button', ['url' => '/']); ?>
Ir a SimpsonsGram
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
SimpsonsGram
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\simpsonsGram\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>