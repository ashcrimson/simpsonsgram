<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row pb-4">
<h1>Recomendados: </h1>
    <?php $__currentLoopData = $recomendados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recomendado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
            <span class="font-weight-bold">
                <a href="/profile/<?php echo e($recomendado->id); ?>">
                <img src="<?php echo e($recomendado->profile->profileImage()); ?>" class="rounded-circle w-100 " style="max-width:40px;">

                    <span class="text-dark pr-4"><?php echo e($recomendado->username); ?></span>
                </a>    
        </p>
        
   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
<div class="row pb-4">
<?php $__currentLoopData = $recomendados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recomendado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $recomendado->profile)): ?>
                    <a href="/profile/<?php echo e($recomendado->id); ?>">Ir a mi perfil</a>
                <?php endif; ?>
        </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-4 offset-4">
            <a href="/p/<?php echo e($post->id); ?>"><img src="/storage/<?php echo e($post->image); ?>" class="w-100"></a>
            
        </div>
    </div>
    <div class="row pt-2 pb-4">
        <div class="col-4 offset-4">
            <p>
            <span class="font-weight-bold">
                <a href="/profile/<?php echo e($post->user->id); ?>">
                <img src="<?php echo e($post->user->profile->profileImage()); ?>" class="rounded-circle w-100" style="max-width:40px;">
                    <span class="text-dark"><?php echo e($post->user->username); ?></span>
                </a>
                
            </span> <?php echo e($post->caption); ?>

            </p>
             
            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-12 d-flex justify-content-center">
            <?php echo e($posts->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simpsonsGram\resources\views/posts/index.blade.php ENDPATH**/ ?>